create definer = root@localhost trigger check_grade_sc
    before insert
    on sc
    for each row
begin
    declare grade int(3);
    set grade=new.Grade;
    if grade<0 or grade>100 then
        signal sqlstate '45000' set message_text ='The score must be between 0 and 100';
    end if;

end;

