create definer = root@localhost trigger sex_check_student
    before insert
    on student
    for each row
begin
    declare sex char(2);
    set sex=NEW.Ssex;
    if sex!='男' and sex!='女' then
        signal sqlstate '45000' set message_text ='The gender must be male or female ';
    end if;
end;

