create definer = root@localhost view student_information_view as
select `design`.`sc`.`Sno`        AS `学号`,
       `design`.`student`.`Sname` AS `姓名`,
       `design`.`sc`.`Cno`        AS `课程号`,
       `design`.`course`.`Cname`  AS `课程名`
from `design`.`student`
         join `design`.`course`
         join `design`.`sc`
where ((`design`.`sc`.`Sno` = `design`.`student`.`Sno`) and (`design`.`sc`.`Cno` = `design`.`course`.`Cno`));

