create definer = root@localhost trigger delete_student
    before delete
    on student
    for each row
    delete from sc
where  sc.Sno=old.Sno;

