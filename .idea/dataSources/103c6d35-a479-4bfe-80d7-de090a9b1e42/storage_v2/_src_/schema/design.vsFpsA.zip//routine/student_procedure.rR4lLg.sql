create
    definer = root@localhost procedure student_procedure(IN sno char(8))
begin
    select Cno as '课程号',Cname as '课程名' from course
        where Cno not in(
        select Cno from sc
        where sc.Sno=sno);
end;

