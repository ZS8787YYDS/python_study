create definer = root@localhost trigger before_insert_student
    before insert
    on student
    for each row
BEGIN
    DECLARE sno_prefix CHAR(4);
    SET sno_prefix = SUBSTRING(NEW.Sno, 1, 4);

    IF sno_prefix != '2004' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Sno must start with '2004'";
    END IF;
END;

