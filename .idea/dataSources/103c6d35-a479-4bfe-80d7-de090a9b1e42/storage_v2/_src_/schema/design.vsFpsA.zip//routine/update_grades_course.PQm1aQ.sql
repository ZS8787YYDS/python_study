create
    definer = root@localhost procedure update_grades_course(IN old_cno char(20), IN new_cno char(20))
BEGIN
    UPDATE sc
    SET Cno = new_cno
    WHERE Cno = old_cno;
END;

