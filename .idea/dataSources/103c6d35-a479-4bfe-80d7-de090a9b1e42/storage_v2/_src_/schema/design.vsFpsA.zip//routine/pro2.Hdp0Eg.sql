create
    definer = root@localhost procedure pro2(IN cname char(20))
begin
    select sc.Cno as '课程号',Cname as '课程名' ,avg(Grade) as '平均分'
    from sc,course
    where sc.Cno=course.Cno
    and course.Cname=cname
    group by sc.Cno;
end;

