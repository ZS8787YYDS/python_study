create
    definer = root@localhost procedure pro1(IN sno char(8), IN cname char(20))
begin
    select sc.Sno as '学号',Sname as '姓名',sc.Cno as '课程号',Grade as '分数'
    from student,course,sc
    where sc.Sno=student.Sno
            and sc.Cno=course.Cno
            and student.Sno=sno
            and course.Cname=cname;
end;

