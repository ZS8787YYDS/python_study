create definer = root@localhost trigger del_trig
    after delete
    on course
    for each row
    delete from sc where cno=OLD.cno;

