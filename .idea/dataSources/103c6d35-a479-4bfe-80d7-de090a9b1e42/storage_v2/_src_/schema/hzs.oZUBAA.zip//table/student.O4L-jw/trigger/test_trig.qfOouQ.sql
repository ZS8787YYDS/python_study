create definer = root@localhost trigger test_trig
    after insert
    on student
    for each row
    insert into test(Sno,date_time) values(NEW.sno,SYSDATE());

