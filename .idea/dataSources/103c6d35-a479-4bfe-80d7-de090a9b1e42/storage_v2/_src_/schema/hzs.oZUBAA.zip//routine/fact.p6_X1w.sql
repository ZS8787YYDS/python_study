create
    definer = root@localhost function fact(i int) returns varchar(10) deterministic
begin
    declare grade varchar(10);
    if i>=90 then
        set grade='A';
    elseif i>=80 then
        set grade='B';
    elseif i>=70 then
        set grade='C';
    elseif i>=60 then
        set grade='D';
    else
        set grade='E';
    end if;
    return grade;
end;

