create
    definer = root@localhost function calculate_sum() returns int deterministic
begin
    declare ans int default 0;
    declare i int default  1;
    while i<=100 do
        set ans=ans+i;
        set i=i+1;
    end while;
    return ans;
end;

