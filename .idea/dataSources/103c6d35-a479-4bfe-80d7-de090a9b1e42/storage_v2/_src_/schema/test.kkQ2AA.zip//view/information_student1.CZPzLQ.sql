create definer = root@localhost view information_student1 as
select `test`.`student`.`sno` AS `学号`, `test`.`student`.`name` AS `姓名`, `test`.`student`.`sex` AS `性别`
from `test`.`student`
where (`test`.`student`.`dept` = 'CS');

