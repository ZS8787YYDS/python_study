create definer = root@localhost view information_student2 as
select `test`.`sc`.`sno` AS `学号`, `test`.`student`.`name` AS `姓名`, `test`.`student`.`sex` AS `性别`
from `test`.`student`
         join `test`.`sc`
where ((`test`.`student`.`dept` = 'CS') and (`test`.`sc`.`cno` = '1') and (`test`.`student`.`sno` = `test`.`sc`.`sno`));

