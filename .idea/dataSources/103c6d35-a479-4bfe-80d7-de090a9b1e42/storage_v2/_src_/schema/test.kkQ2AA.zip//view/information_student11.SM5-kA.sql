create definer = root@localhost view information_student11 as
select `test`.`student`.`sno` AS `sno`, `test`.`student`.`name` AS `name`, `test`.`student`.`sex` AS `sex`
from `test`.`student`
where (`test`.`student`.`dept` = 'CS');

