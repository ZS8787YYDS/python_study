create definer = root@localhost view birth_student as
select `test`.`student`.`sno`                     AS `sno`,
       `test`.`student`.`name`                    AS `name`,
       (year(curdate()) - `test`.`student`.`age`) AS `year(current_date)-age`
from `test`.`student`;

