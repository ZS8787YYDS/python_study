create definer = root@localhost view woman_student as
select `test`.`student`.`sno`  AS `sno`,
       `test`.`student`.`name` AS `name`,
       `test`.`student`.`sex`  AS `sex`,
       `test`.`student`.`age`  AS `age`,
       `test`.`student`.`dept` AS `dept`
from `test`.`student`
where (`test`.`student`.`sex` = '女');

