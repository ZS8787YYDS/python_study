create definer = root@localhost view performance_student as
select `test`.`sc`.`sno` AS `sno`, avg(`test`.`sc`.`grade`) AS `avg(grade)`
from `test`.`sc`
group by `test`.`sc`.`sno`;

