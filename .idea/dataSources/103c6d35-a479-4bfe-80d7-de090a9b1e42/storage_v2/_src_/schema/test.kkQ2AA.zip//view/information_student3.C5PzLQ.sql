create definer = root@localhost view information_student3 as
select `test`.`student`.`sno` AS `sno`, `test`.`student`.`name` AS `name`, `test`.`student`.`sex` AS `sex`
from `test`.`student`
         join `test`.`sc`
where ((`test`.`student`.`sno` = `test`.`sc`.`sno`) and (`test`.`student`.`dept` = 'CS') and
       (`test`.`sc`.`cno` = '1') and (`test`.`sc`.`grade` > 90));

