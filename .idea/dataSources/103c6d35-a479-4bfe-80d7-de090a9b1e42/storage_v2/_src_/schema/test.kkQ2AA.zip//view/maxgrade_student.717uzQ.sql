create definer = root@localhost view maxgrade_student as
select `test`.`sc`.`sno` AS `sno`, max(`test`.`sc`.`grade`) AS `max(grade)`
from `test`.`sc`
group by `test`.`sc`.`sno`;

